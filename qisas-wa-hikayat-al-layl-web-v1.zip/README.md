# قصص وحكايات الليل — Web
موقع مستقل للمشاهدة، منفصل عن Expo.
يقرأ القصص المنشورة من جدول `public.قصص` في Supabase ويشغل `video_url` داخل الصفحة.
ضع `NEXT_PUBLIC_SUPABASE_URL` و`NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` في Vercel.
لا تضع service_role في الموقع.
